package com.example.ali_danish_s2024847;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.Xml;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Callable;

//Replaces Runnable; Allows Class to be returned, Taken from StackOverflow
//TODO: ReStructure as doesnt work as intended
public class Task implements Callable<Weather> {
    private String result;
    private final String url;
    //Extra incomplete Logic remove for ItemList, Hence no
    private final ArrayList<Item> list = new ArrayList<Item>();
    private final Item item = new Item();
    private Integer itmCount = 0;
    private Activity activity;
    private TextView textView;
    private Weather data;

    public Task(String url) {
        this.url = url;
    }

    //Used to update Views in MainActivty, replaced with Returning Class Instead.
    public Task(Activity activity, TextView textview, Weather data, String url) {
        this.url = url;

        this.activity = activity;
        this.textView = textview;
        this.data = data;
    }

    @Override
    public Weather call() {
        URL aurl;
        URLConnection yc;
        BufferedReader in = null;
        String inputLine = "";

        Log.e("MyTag", "In Run");
        try {
            Log.e("MyTag", "In Try");
            aurl = new URL(url);
            yc = aurl.openConnection();
            in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
            while ((inputLine = in.readLine()) != null) {
                result += inputLine;
                Log.e("MyTag", inputLine);
            }
            in.close();
        } catch (IOException ae) {
            ae.printStackTrace();
            Log.e("MyTag", "IoException");
        }
        //Get rid of the first tag <?xml version="1.0" encoding="utf-8"?>
        int i = result.indexOf(">");
        result = result.substring(i + 1);
        Log.e("MyTag - Cleaned", result);


        //New Code

        data = parseData(result);
        return data;
    }


    public Weather parseData(String result) {
        Weather weather = new Weather();
        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser parser = Xml.newPullParser();
            //TODO: Rule to display full tag rather than simplification; Example- Atom:Link into Link. Includes Word & Punctuation; Semi-Colon.
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(new StringReader(result));


            String currentTag = "";
            Item item = new Item();
            //TODO: Revise as not working as expected; Used to address conflicting Tags embedded in Others; Like Title
            boolean ChannelTag = false, ImgTag = false, ItemTag = false;


            int eventType = parser.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG) {
                    currentTag = parser.getName();

                    //Used to Display Tags for debugging parsing
                    //displayTags(currentTag, parser, eventType);

                    if (currentTag.equalsIgnoreCase("channel")) {
                        Log.i("new", "Create new Channel...");
                        ChannelTag = true;
                        // weather = new Weather();
                    } else if (currentTag.equalsIgnoreCase("image")) {
                        Log.i("new", "Create new Image...");
                        ImgTag = true;
                    } else if (currentTag.equalsIgnoreCase("item")) {
                        Log.i("new", "Create New Itm..." + itmCount);
                        item = new Item();
                        //weather.setItem(item);
                        ItemTag = true;
                    }
                } else if (eventType == XmlPullParser.TEXT && !parser.isWhitespace()) {
                    String value = parser.getText().trim();

                    //TODO: In HindSight, 3 seperate Methods would've been more efficient
                    if (itmCount <1) {
                        weather = getChannel(value, currentTag, ChannelTag, ImgTag, weather);
                    } else {
                        item = getItem(value, currentTag, ItemTag, item);
                    }
                    // Log.e("Updated: Text\t", value);

                } else if (eventType == XmlPullParser.END_TAG) {
                    currentTag = parser.getName();

                    //currentTag = "";
                    //ChannelTag = false;
                    //ImgTag = false;
                    //ItemTag = false;

                    if (currentTag.equalsIgnoreCase("channel")) {
                        ChannelTag = false;
                        //Log.i("new", "tag: " + ChannelTag);
                        // weather = new Weather();
                    } else if (currentTag.equalsIgnoreCase("image")) {
                        ImgTag = false;
                    } else if (currentTag.equalsIgnoreCase("item")) {
                        // Log.d("mew", ""+ itmCount);
                        weather.setItem(item);
                        list.add(itmCount, item);
                        itmCount++;

                        ImgTag = false;
                    }
                    //displayTags(currentTag, parser, eventType);
                }
                eventType = parser.next();
            }
            Log.e("Updated: text+Tag\t", "After:\n" + weather.toString());
        } catch (XmlPullParserException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        weather.setItems(list);
        return weather;

    }


    public Weather getChannel(String value, String currentTag, boolean ChannelTag, boolean ImgTag, Weather temp) {
        if (!value.isEmpty()) {
            currentTag = currentTag.replaceAll("\\s+", "");
            currentTag = currentTag.toLowerCase();
            switch (currentTag) {
                case "title":
                    // weather.setTitle();
                    if (ChannelTag && !ImgTag) {
                        temp.setTitle(value);
                    } else {
                        temp.setImgTitle(value);
                    }
                    break;
                case "link":
                    // weather.setTitle();
                    if (ChannelTag && !ImgTag) {
                        temp.setLink(value);
                    } else {
                        temp.setImgLink(value);
                    }
                    break;
                case "description":
                    temp.setDescription(value);
                    break;
                case "language":
                    temp.setLanguage(value);
                    break;
                case "copyright":
                    temp.setCopyright(value);
                    break;
                case "pubdate":
                    temp.setPubDate(value);
                    break;
                case "dc:date":
                    temp.setDcDate(value);
                    break;
                case "dc:language":
                    temp.setDcLanguage(value);
                    break;
                case "dc:rights":
                    temp.setDcRights(value);
                    break;
                case "atom:link":
                    temp.setAtomLink("To be Parsed");
                    break;
                //TODO Image
                //Title Addressed Above
                case "url":
                    temp.setImgUrl(value);
                    break;
                //Link Addressed Above
            }
        }
        return temp;
    }

    public Item getItem(String value, String currentTag, boolean ItemTag, Item temp) {
        if (!value.isEmpty()) {
            currentTag = currentTag.replaceAll("\\s+", "");
            currentTag = currentTag.toLowerCase();
            switch (currentTag) {
                case "title":
                    // weather.setTitle();
                    if (ItemTag) {
                        temp.setItmTitle(value);
                    }
                    break;

            }
        }
        return temp;
    }

    public Weather getDataValuesFromtag(String value, String currentTag, boolean ChannelTag, boolean ImgTag, boolean ItemTag, Weather weather, Item itemsss) {
        Weather temp = new Weather();
        return temp;
    }


    //Below for Displaying Tags and testing of Specials cases and further Parsing, Like Description for Wind Direction, Date Etc.
    public void displayTags(String value, XmlPullParser parser, int eventType) {
        Weather weather = new Weather();
        //Below for Special Cases as Indicated By Rule Above
        switch (value) {
            case "rss":
                //Skip RSS
                //Log.e("Updated\t", "Rss skip");
                break;
            case "description":
                //Removes Commas and Spaces into Array... each index item like [1] for Wind Direction
                String[] split = value.split(",[ ]*");
            case "atom:link":
                if (eventType == XmlPullParser.START_TAG) {

                    String link = parser.getAttributeValue(null, "href");
                    String type = parser.getAttributeValue(null, "type");
                    String rel = parser.getAttributeValue(null, "rel");

                    Log.e("tag1", link + "\n" + type + "\n" + rel);
                }
                break;
            default:
                Log.e("Updated: text+Tag\t", value);
                break;
        }
    }
}
