package com.example.ali_danish_s2024847;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;


public class Weather {
    private String title;
    private String link;
    private String description;
    private String language;
    private String copyright;
    private String pubDate;

    //Other
    private String dcDate;
    private String dcLanguage;
    private String dcRights;
    private String atomLink;

    //Image? [1 set]
    private String image;
    private String imgTitle;
    private String imgUrl;
    private String imgLink;

    //Items [3/1 set]
    private  ArrayList<Item> items;
    private Item item;

    public Weather() {
        items = new ArrayList<Item>();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getCopyright() {
        return copyright;
    }

    public void setCopyright(String copyright) {
        this.copyright = copyright;
    }

    public String getPubDate() {
        return pubDate;
    }

    public void setPubDate(String pubDate) {
        this.pubDate = pubDate;
    }


    //
    //Other
    //

    public String getDcDate() {
        return dcDate;
    }

    public void setDcDate(String dcDate) {
        this.dcDate = dcDate;
    }

    public String getDcLanguage() {
        return dcLanguage;
    }

    public void setDcLanguage(String dcLanguage) {
        this.dcLanguage = dcLanguage;
    }

    public String getDcRights() {
        return dcRights;
    }

    public void setDcRights(String dcRights) {
        this.dcRights = dcRights;
    }

    public String getAtomLink() {
        return atomLink;
    }

    public void setAtomLink(String atomLink) {
        this.atomLink = atomLink;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getImgTitle() {
        return imgTitle;
    }

    public void setImgTitle(String imgTitle) {
        this.imgTitle = imgTitle;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getImgLink() {
        return imgLink;
    }

    public void setImgLink(String imgLink) {
        this.imgLink = imgLink;
    }


    //
    //Items
    //

    public ArrayList<Item> getItems() {
        return items;
    }

    public void setItems(Item item, int pos) {
        items.set(pos, item);
    }
    public void setItems(ArrayList<Item> item) {
        items = item;
        //items.add(item);
    }
    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    @Override
    public String toString() {
        return "Weather{\n" +
                "title=\n" + title + '\n' +
                "link=" + link + '\n' +
                "description='" + description + '\n' +
                "language='" + language + '\n' +
                "copyright='" + copyright + '\n' +
                "pubDate='" + pubDate + '\n' +
                "dcDate='" + dcDate + '\n' +
                "dcLanguage='" + dcLanguage + '\n' +
                "dcRights='" + dcRights + '\n' +
                "atomLink='" + atomLink + '\n' +
                "\n\nimage='" + image + '\n' +
                "imgTitle='" + imgTitle + '\n' + //Title same as before
                "imgUrl='" + imgUrl + '\n' +
                "imgLink='" + imgLink + '\n' +
                "\n\nitems= {" + items.toString() +
                "}\n}";
    }

    public String toStringItems() {
        return "Weather{" +
                "items=" + items.toString() + //Arrays.toString(items) +
                '}';
    }
}

