package com.example.ali_danish_s2024847;

import android.app.Dialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MainActivity extends AppCompatActivity {
    //Assign Cities and Data for URL
    public static final Map<String, Integer> cities;

    static {
        Hashtable<String, Integer> tmp = new Hashtable<String, Integer>();
        tmp.put("Glasgow", 2648579);
        tmp.put("London", 2643743);
        tmp.put("New York", 5128581);
        tmp.put("Oman", 287286);
        tmp.put("Mauritius", 934154);
        tmp.put("Bangladesh", 1185241);
        //Immutable HashMap
        cities = Collections.unmodifiableMap(tmp);//Data is Final
    }
    private Weather latest;
    private Weather data3days;
    private int cycles = 0;
    private final int itmCount = 0;
    private TextView rawDataDisplay, acknowledgement, Title, text1, latestinvisText1, title;
    private Button startButton, location;
    private FloatingActionButton top;
    private ScrollView scroll;

    private boolean pass;
    private String result, key = "Manchester", value = "2643123"; //Manchester
    private final String url1 = "https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/";
    private final String url2 = "https://weather-broker-cdn.api.bbci.co.uk/en/observation/rss/";

    //Default Link
    private String urlSource = "https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/2643123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Instantiate visual elements
        setContentView(R.layout.activity_main);
        //Title = (TextView) findViewById(R.id.latest).findViewById(R.id.Title);
        latestinvisText1 = findViewById(R.id.latest).findViewById(R.id.text1_invis);
        rawDataDisplay = findViewById(R.id.rawDataDisplay);
        acknowledgement = findViewById(R.id.acknowledgement);
        scroll = findViewById(R.id.scrollview);
        startButton = findViewById(R.id.startButton);
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startProgress();
                //search();

                update();
            }
        });

        topBtn();
        search();
        startProgress();

        rawDataDisplay.setText(" empty ");
        //acknowledgement.setText("o");

        //TODO:Refreshes Data & Displays Every ...  Sec
        //New Handler.postDelayed(new Runnable() {...}
        //Start Timer Thread to execute Code
        new Timer().scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                //Used to tackle Error involving view: android.view.ViewRootImpl$CalledFromWrongThreadException
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        startProgress();
                        update();
                        cycles++;
                        acknowledgement.setText("[~10s]Num Of Refresh:\t" + cycles);
                    }
                });
            }
        }, 10000, 10000);


        //MainActivity.this.runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                // this code will be executed after 2 seconds
//                Log.d("UI thread2", "I am the UI thread");
//                startProgress();
//                    }
//                };
//                thread.start();
//            }
//        }, 5000, 5000); //5sec


//        EdgeToEdge.enable(this);
//        setContentView(R.layout.activity_main);
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
//            return insets;
//        });
//    }
    }

    public void update() {
        View[] cards = new View[4];
        cards[0] = findViewById(R.id.latest);
        cards[1] = findViewById(R.id.day1);
        cards[2] = findViewById(R.id.day2);
        cards[3] = findViewById(R.id.day3);

        for (View temp : cards) {
            OpenCards(temp);
        }

        if (itmCount > 2) {
            views_3days(cards[1], 0);
            views_3days(cards[2], 1);
            views_3days(cards[3], 2);
        }
    }

    public void topBtn() {
        // View btn = findViewById(R.id.floatingFrame);
        FrameLayout frameLayout = findViewById(R.id.floatingFrame);
        frameLayout.setClickable(true);
        top = frameLayout.findViewById(R.id.floatingbtn);
        top.setOnClickListener(new View.OnClickListener() {//TODO: Convert to Hovering Bottom Left with Arrow Icon
            @Override
            public void onClick(View v) {
                scroll.fullScroll(ScrollView.FOCUS_UP);//Jumps to Top
                // Log.d("message", "top");
            }
        });

    }

    //Open Weather Sections for More Details on Click
    public void OpenCards(View te) {
        // latest.setBackgroundColor(0xFF00FF00);
        FrameLayout frameLayout = te.findViewById(R.id.frameLayout);
        frameLayout.setClickable(true);

        frameLayout.setOnClickListener(new View.OnClickListener() {
            //Show Hidden Card elements
            @Override
            public void onClick(View v) {
                // rawDataDisplay.setText("test");
                View hiddenView = frameLayout.findViewById(R.id.invisible);
                hiddenView.setVisibility(hiddenView.getVisibility() == View.GONE ? View.VISIBLE : View.GONE);
            }
        });
    }


    //Allow User to Select location, Default Manchester, and Update Data.
    public void search() {
        View latest = findViewById(R.id.latest);
        text1 = latest.findViewById(R.id.text1);
        title = latest.findViewById(R.id.Title);
        location = findViewById(R.id.location);

        location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(MainActivity.this);
                LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
                View view1 = inflater.inflate(R.layout.search, null);
                ListView listView = view1.findViewById(R.id.listView);
                SearchView searchView = view1.findViewById(R.id.searchView);

//               List<String> dataList = new ArrayList<>();
//                for (Map.Entry<String, Integer> entry : cities.entrySet()) {
//                    dataList.add(entry.getKey() + ": " + entry.getValue());
//                }
                List<String> keyList = new ArrayList<>(cities.keySet());
                final ArrayAdapter<String> stringArrayAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, keyList);
                listView.setAdapter(stringArrayAdapter);

                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        //Text Value: City
                        value = listView.getItemAtPosition(position).toString();
                        //Id Value: Rss Code
                        key = keyList.get(position);
                        Integer value = cities.get(key);

                        title.setText("Locaiton ID: " + value);

                        //Add ID onto URl: 3Days
                       String temp = url1 + value;
                        urlSource = temp;
                        Log.d("data", urlSource);
                        startProgress();

                        //Add ID onto URl: Latest
                        temp = url2 + value;
                        urlSource = temp;
                        Log.d("data", urlSource);
                        //pass=true;
                        startProgress();

                        //Display Location
                        location.setText("Currently Selected: \n -- " + MainActivity.this.value.toUpperCase() + " --");

                        dialog.dismiss();
                    }
                });

                //Necessary Methods, Taken From StackOverFlow
                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String newText) {
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        stringArrayAdapter.getFilter().filter(newText);
                        return false;
                    }
                });
                dialog.setContentView(view1);
                dialog.show();
            }
        });
    }


    public void views_3days(View te, int num) {
        View view = te;
        Title = view.findViewById(R.id.Title);
        Title.setText(latest.getItems().get(num).getItmTitle());
        //Title.setText("" + itmCount);

        //TODO:Latest to 3day
        latestinvisText1.setText("Latest");
    }

    public void startProgress() {
        //Get Data
        Task updateUITask = new Task(urlSource);

        //Used to retrieve data from thread, Taken From Stack OverFlow
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Future<Weather> future = executor.submit(updateUITask);

        try {
               latest = future.get();

               //Update Data based of which XMl
                if (!pass) {
                             data3days = future.get();
                    text1.setText(data3days.getTitle() + key + "\n" + "\t [Mixed Up with Item Tag]");

                } else {


                   // if (key != null)
                        text1.setText(latest.getTitle());

                }
            rawDataDisplay.setText("For:\t" + key);
            latestinvisText1.setText(data3days.getTitle() +"\n" +key);
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        } catch (NullPointerException e) {
            title.setText("Error: Connection Interupted");
        }
        executor.shutdown();


        //TODO
        //Task task = new Task(MainActivity.this, rawDataDisplay, new Weather(), urlSource);
        //new Thread(task).start();
        //new Thread(new Task(urlSource)).start();
    }

}