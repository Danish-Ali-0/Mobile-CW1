package com.example.ali_danish_s2024847;

public class Item {
    //Item [3 items?] - Separate Class
    //private String item;
    private String itmTitle;
    private String itmLink;
    private String itmDescription;
    private String itmPubDate;
    private String itmGuid;
    private String itmDate;
    private String itmPoint;

    public Item() {
    }

    public Item(String test) {

    }
    public String getItmTitle() {
        return itmTitle;
    }

    public void setItmTitle(String itmTitle) {
        this.itmTitle = itmTitle;
    }

    public String getItmLink() {
        return itmLink;
    }

    public void setItmLink(String itmLink) {
        this.itmLink = itmLink;
    }

    public String getItmDescription() {
        return itmDescription;
    }

    public void setItmDescription(String itmDescription) {
        this.itmDescription = itmDescription;
    }

    public String getItmPubDate() {
        return itmPubDate;
    }

    public void setItmPubDate(String itmPubDate) {
        this.itmPubDate = itmPubDate;
    }

    public String getItmGuid() {
        return itmGuid;
    }

    public void setItmGuid(String itmGuid) {
        this.itmGuid = itmGuid;
    }

    public String getItmDate() {
        return itmDate;
    }

    public void setItmDate(String itmDate) {
        this.itmDate = itmDate;
    }

    public String getItmPoint() {
        return itmPoint;
    }

    public void setItmPoint(String itmPoint) {
        this.itmPoint = itmPoint;
    }

    @Override
    public String toString() {
        return "\nItem{" +
                "itmTitle='" + itmTitle + '\n' +
                ", itmLink='" + itmLink + '\n' +
                ", itmDescription='" + itmDescription + '\n' +
                ", itmPubDate='" + itmPubDate + '\n' +
                ", itmGuid='" + itmGuid + '\n' +
                ", itmDate='" + itmDate + '\n' +
                ", itmPoint='" + itmPoint + '\n' +
                "}\n\n";
    }
}

